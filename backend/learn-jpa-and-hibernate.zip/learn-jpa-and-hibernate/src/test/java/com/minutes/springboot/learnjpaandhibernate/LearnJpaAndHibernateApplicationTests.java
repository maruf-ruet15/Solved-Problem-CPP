package com.minutes.springboot.learnjpaandhibernate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnJpaAndHibernateApplicationTests {

	@Test
	void contextLoads() {
	}

}
